# -*- coding: utf-8 -*-
from four import *
import os
import tensorflow as tf
from keras.backend.tensorflow_backend import set_session
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.optimizers import Adam
from keras.layers.recurrent import LSTM, GRU
from keras.layers import Bidirectional
from keras.layers.convolutional import Convolution1D, AveragePooling1D
from keras.callbacks import EarlyStopping
from sklearn.model_selection import KFold
from sklearn.metrics import roc_curve, auc, roc_auc_score,accuracy_score,recall_score,f1_score,precision_score
import numpy as np
import argparse
from sklearn.metrics import plot_roc_curve,precision_recall_curve,average_precision_score

# 配置GPU和TensorFlow会话：
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
config = tf.compat.v1.ConfigProto()
config.gpu_options.allocator_type = 'BFC'
config.gpu_options.per_process_gpu_memory_fraction = 0.3
config.gpu_options.allow_growth = True
tf.compat.v1.keras.backend.set_session(tf.compat.v1.Session(config=config))


# 定义函数run_CRIP(parser)，该函数用于运行CRIP模型的训练和评估过程。它接受一个parser参数，用于解析命令行参数。
def run_CRIP(parser):
    # 首先从命令行参数中获取要处理的蛋白质名称、批处理大小、隐藏层大小、训练轮数等信息。
    protein = parser.protein
    # model_dir = parser.model_dir
    batch_size = parser.batch_size
    hiddensize = parser.hiddensize
    n_epochs = parser.n_epochs
    nbfilter = parser.nbfilter
    trainXeval, test_X, trainYeval, test_y = dealwithdata(protein)  # 使用dealwithdata(protein)函数处理数据，得到训练集和测试集的特征和标签。
    test_y = test_y[:, 1]
    kf = KFold(n_splits=5)  # 使用K折交叉验证方法划分训练集并进行模型训练和评估。
    # 创建一个空列表，用于存储每个折叠的FPR、TPR值和AUC值。
    fpr_list = []
    tpr_list = []
    aucs = []
    Acc = []
    precision1 = []
    recall1 = []
    fscore1 = []
    for train_index, eval_index in kf.split(trainYeval):  # 在每个训练集和验证集的划分上，创建一个CNN模型，并使用训练数据进行模型训练。
        # 在每个训练集和验证集的划分上，将训练集数据和标签分别赋值给train_X和train_y，将验证集数据和标签分别赋值给eval_X和eval_y。
        train_X = trainXeval[train_index]
        train_y = trainYeval[train_index]
        eval_X = trainXeval[eval_index]
        eval_y = trainYeval[eval_index]
        print('configure cnn network')
        model = Sequential()  # 创建一个序贯模型model = Sequential()，用于构建卷积神经网络模型。
        # 添加卷积层Convolution1D到模型中，指定输入维度为56、输入长度为101，卷积核数量为nbfilter，卷积核长度为7，边界模式为"valid"，激活函数为ReLU，子采样长度为1。
        model.add(
            Convolution1D(input_dim=56, input_length=101, nb_filter=nbfilter, filter_length=7, border_mode="valid",
                          ####
                          activation="relu", subsample_length=1))
        # 添加平均池化层AveragePooling1D到模型中，指定池化窗口大小为5。
        model.add(AveragePooling1D(pool_size=5))
        # 添加Dropout层Dropout到模型中，设置丢弃
        # 率为0.5，用于防止过拟合。
        model.add(Dropout(0.5))
        # model.add(LSTM(128, input_dim=102, input_length=31, return_sequences=True))
        # 添加双向GRU层Bidirectional(GRU)到模型中，隐藏层大小为hiddensize，设置返回完整序列。
        model.add(Bidirectional(GRU(hiddensize, return_sequences=True)))
        # model.add(Bidirectional(LSTM(hiddensize, return_sequences=True)))
        # 添加展平层Flatten到模型中，用于将输入展平为一维向量。
        model.add(Flatten())
        # 添加全连接层Dense到模型中，神经元数量为nbfilter，激活函数为ReLU。
        model.add(Dense(nbfilter, activation='relu'))
        # 添加Dropout层Dropout到模型中，设置丢弃率为0.25，用于防止过拟合。
        model.add(Dropout(0.25))
        # 添加输出层Dense到模型中，神经元数量为2，对应两个类别。
        model.add(Dense(2))
        # 添加激活层Activation，使用softmax函数进行多分类。
        model.add(Activation('softmax'))
        # sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
        # 编译模型，设置损失函数为二分类交叉熵（binary_crossentropy），优化器为Adam，学习率为1e-4。
        model.compile(loss='categorical_crossentropy', optimizer=Adam(lr=1e-4))  # 'rmsprop'
        print('model training')
        # checkpointer = ModelCheckpoint(filepath="models/" + protein + "_bestmodel.hdf5", verbose=0, save_best_only=True)
        # 创建EarlyStopping回调函数earlystopper，用于在验证集上监控验证集损失，并设置最大的停止训练的轮数为5。
        earlystopper = EarlyStopping(monitor='val_loss', patience=5, verbose=0)
        # 使用model.fit函数训练模型，传入训练数据、训练标签、批处理大小、训练轮数、验证集数据、验证集标签以及回调函数earlystopper。
        model.fit(train_X, train_y, batch_size=batch_size, epochs=n_epochs, verbose=0,
                  validation_data=(eval_X, eval_y),
                  callbacks=[earlystopper])
        # 训练完成后，使用测试集进行预测，并计算预测结果的AUC值。
        predictions = model.predict_proba(test_X)[:, 1]
        pre= np.argmax(model.predict_proba(test_X), axis=-1)
        fpr, tpr, _ = roc_curve(test_y, predictions)
        precision,recall,thresholds=precision_recall_curve(test_y, predictions)
        fpr_list.append(fpr)
        tpr_list.append(tpr)
        AP = average_precision_score(test_y, predictions)#
        auc = roc_auc_score(test_y, predictions)
        precision = precision_score(test_y, pre)
        recall = recall_score(test_y, pre)
        fscore = f1_score(test_y, pre)
        acc = accuracy_score(test_y, pre)#
        aucs.append(auc)
        Acc.append(acc)
        precision1.append(precision)
        recall1.append(recall)
        fscore1.append(fscore)

    # 保存ROC数据
    if len(fpr_list) == 5:
        roc_data = np.column_stack((fpr_list[-1], tpr_list[-1]))
        np.savetxt('../result/{}(AUC={:.4f}).txt'.format(protein, np.mean(aucs)), roc_data, delimiter='\t')


    print("acid AUC: %.4f " % np.mean(aucs), protein)  # 输出平均AUC值和蛋白质名称。
    print("acid ACC: %.4f " % np.mean(Acc),protein)
    print("acid precision1: %.4f " % np.mean(precision1),protein)
    print("acid recall1: %.4f " % np.mean(recall1), protein)
    print("acid fscore1: %.4f " % np.mean(fscore1), protein)


    # 绘制AUC曲线
    # plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置中文字体
    # plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
    # plt.plot(range(1, len(aucs) + 1), aucs, marker='o')
    # plt.xlabel('迭代次数')
    # plt.ylabel('AUC')
    # plt.title('AUC曲线')
    # plt.show()

    # 绘制每个折叠的ROC曲线
    # plt.figure()
    # for i in range(len(fpr_list)):
    #     plt.plot(fpr_list[i], tpr_list[i], label='第{}折'.format(i + 1))
    # plt.plot([0, 1], [0, 1], linestyle='--', color='r', label='random guessing')
    # plt.xlabel('假阳率（FPR）')
    # plt.ylabel('真阳率（TPR）')
    # plt.title('ROC曲线')
    # plt.legend()
    # plt.show()


# 定义函数parse_arguments(parser)，用于解析命令行参数。
def parse_arguments(parser):
    # 创建一个命令行参数解析器，并添加protein、nbfilter、hiddensize、batch_size、n_epochs等参数。
    parser.add_argument('--protein', type=str, metavar='<data_file>', required=True,
                        help='the protein for training model')
    parser.add_argument('--nbfilter', type=int, default=102, help='use this option for CNN convolution')
    parser.add_argument('--hiddensize', type=int, default=120, help='use this option for LSTM')
    parser.add_argument('--batch_size', type=int, default=50,
                        help='The size of a single mini-batch (default value: 50)')
    parser.add_argument('--n_epochs', type=int, default=30, help='The number of training epochs (default value: 30)')
    args = parser.parse_args()
    return args


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    args = parse_arguments(parser)
    run_CRIP(args)
